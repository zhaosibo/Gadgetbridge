/* Copyright JS Foundation and other contributors, http://js.foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 class C extends Array {
   constructor (a, b) {
     var a = eval ('super (arguments);');
   }
 }

 class D extends C {
   constructor () {
      var a = eval ("eval ('super (1, 2);')");
      return
   }
 }

 var d = new D;
 assert (JSON.stringify (d) === '[{"0":1,"1":2}]');
 assert (d + "" === "[object Arguments]");
 assert (d.length === 1);
